# py-line fishing (CLI first)

Simple fishing simulation that runs in the terminal; type `cast`, `bag`, or `market` and watch the text HUD update.

## Docker

### Build image (optional)

```bash
docker build -t py-line-fishing .
```

### Run locally with access to your X11 display (Linux)

```bash
docker run --rm -it py-line-fishing
```

If you need a headless way to exercise the game for debugging purposes, wrap the run with `xvfb-run`:

```bash
xvfb-run docker run --rm -it py-line-fishing
```

## Running locally (recommended)

```bash
python pro_fishing_game.py
```

Once you run `python pro_fishing_game.py` you’ll choose (or create) a profile name, get a HUD with your rod/bait/boat and prompts like:

```
 midas@L-1$
```

Commands are still `cast`, `bag`, `market`, `help`, and `quit`, but the new loop auto-saves your tokens/inventory/last catch/gear/stats after every action so you can resume later. The save file is `pyline_saves.json` in the repo folder. The HUD and command prompt use ANSI colors for readability (`NO_COLOR=1` will disable them if needed).

`cast` keeps the bite delay (3–7 s now) and the HUD shows stats such as total lifetime tokens and biggest catch per profile.
The HUD uses ANSI colors (tokens, rarity, commands) so it’s easier to scan—disable your terminal’s color support or set `NO_COLOR=1` if you prefer monochrome output.

## Git & GitHub

To start versioning the project locally:

```bash
git init
git add .
git commit -m "Initial dockerized py-line fishing"
```

To publish it on GitHub:

1. Create a repository on GitHub named `py-line fishing`.
2. Add the GitHub remote and push:
   ```bash
   git remote add origin git@github.com:your-username/py-line-fishing.git
   git push -u origin main
   ```

Adjust the remote URL and branch name as needed to match the repository you create.
