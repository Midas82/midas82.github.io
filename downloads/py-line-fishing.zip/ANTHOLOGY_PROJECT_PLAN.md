# Anthology Project Plan

This document captures the **full forensic plan** for turning the dozen tomes you gathered under `/home/midas/Desktop/TOMES` into a single **shared CLI anthology engine** (a “story-archive” on top of the existing `py-line fishing` CLI). The focus is on delivering:

1. Detailed ingestion of every source tome (Copilot, GPT, Gemini, Grok, Perplexity, Ninja, Microsoft Copilot, etc.).
2. A shared data model for nodes, arcs, relics, allies, and cross-arc stats.
3. CLI UI + persistence that lets players choose any tome, run through it, *and* carry meaningful state across tales.
4. Integration guidance on how to expand additional mechanical layers (rod/bait/boat or training systems) later.

--- 

## 1. What we have today

| Source | Number of tomes | Notable hooks |
| --- | --- | --- |
| `copilotgittomes.txt` | 5 (siege, forest, space, court, cyberpunk) | Shared relic tokens, location codes, menu/ stat map |
| `gpttomes.txt` | 5 (harbor, orbital, desert train, neon city, lanternwood) | Shared tokens, allied factions, CLI menu with commands |
| `gemini tomes.txt` | 5 (sun\-eater, cyber-noir, weird west, survival horror, post\-apoc jungle) | Four tone variants plus stat map |
| `groktomes.txt` | 5 (ashen covenant, verdant engine, neon shogunate, hollow sky, porcelain empire) | Mythos of “The Fracture”, shared stat map, multi-tone options |
| `PERPLEXITYTOMES.txt` | 5 (glass archivists, drowned port, velvet concord, cog engine, sky library) | Menu+stat map, suggestion for tone presets |
| `NINJATOME.txt` | 5 (hollow veil, silent season, ash clockmaker, hollowing, weightless hour) | Additional persistent hooks, cosmic myth |
| `MICROSOFTCOPILOTTHINKINGTOME.txt` | 5 (blood desert, neon city, verdant labyrinth, void ship, clockwork revolution) | Stories with “shared menu” and resource map |
| `microsoft copilottomes.txt` | 5 (chronicles of iron crown, neon veins, verdant labyrinth, void echoes, clockwork dominion) | Deep branch outlines and repeated menu map |

**Next step:** unify these into structured JSON/ YAML so the engine can load tomes programmatically instead of scanning text files manually.

## 2. Data model

- **`tomes/` directory** (to create within the repo):
  - Each tome described as:
    ```
    {
      "id": "copilot-ash",
      "title": "Steel & Ashes",
      "logline": "...",
      "roles": [...],
      "nodes": [
        {
          "id": "S1",
          "title": "The City Gate Breach",
          "description": "...",
          "choices": [
            { "command": "rally the guards", "outcome": "...", "flags": ["reputation:loyalist"] },
            ...
          ]
        },
        ...
      ],
      "persistentHooks": {
        "relics": ["Saltbound Charm"],
        "flags": ["DEBT_CLEARED"],
        "factions": ["Greyharbor"],
        "currencies": ["Guild Scrip"],
        "stats": ["tokens","reputation"]
      },
      "menuFlavor": "...", // shared menu blurbs from each source
      "replayIncentive": "..."
    }
    ```

- **Shared state** (persisted to `pyline_saves.json`) will track:
  - `globalTokens`: map of token pools (Harbor, Corp, Ember, etc.) normalized to a single `balance`.
  - `relics`: list of strings describing unique artifacts (Cross-ref: multiple sources mention relics such as `Saltbound Charm`, `Tesserium Fragment`, `Ash Blade`, etc.).
  - `allies`: keyed by name with tags like `sourceTome`, `bonus`, `used`.
  - `factions`: map of names -> integer (−2 to +2) to gate future node access.
  - `metaFlags`: e.g., `FOREST_SAVED`, `AI_ALLY`, `TIME_RESET`, `NEON_SAINT`.
  - `playerProfiles`: retains `playerName`, `lastTome`, `stats`.

- **Node command parsing**:
  - Normalize inputs via synonyms (ex: “cast”, “launch line”, “throw rod” → `cast`).
  - Each choice can expose a `command` string for CLI help, a `roll` (if partial randomness), `cost` (tokens, relic), and `effects`.
  - Randomness seeds mentioned (e.g., `biteDelay between 3–12 seconds`, `ash storm d6`), so incorporate simple RNG for events/outcome variations.

## 3. UI / CLI design

1. **Top-level menu** (reuse the shared menu seeds from each file):
   ```
   === ARCHIVE OF TOMES ===
   1. Steel & Ashes…
   2. Verdant Shadows…
   ...
   select <number> | stats | relics | exit
   ```

2. **Prompt**: keep the colored prompt we already built, but include tome context:
   ```
   [player@location tomes=Steel & Ashes]$ cast
   ```
3. Display HUD cross-arc info (tokens, bag, record) plus summary of nodes accessible in current run (use `print_hud`).

## 4. Implementation plan

### Phase 1 – Data ingestion & tooling
1. Create `tools/parse_tomes.py` (or similar script) to:
   - Read each `.txt` in `/home/midas/Desktop/TOMES`.
   - Extract sections (title, nodes, choices, persistent hooks).
   - Output JSON per tome into the repo (e.g., `data/anthology/tomes/copilot_steel_ashes.json`).
2. Standardize node IDs and `choice` structure so the engine can render them uniformly.
3. Document the data contracts in `ANTHOLOGY_SCHEMA.md` (if needed later).

### Phase 2 – Engine expansion
1. Extend `pyline_saves.json` schema to include the new shared state.
2. Add a CLI command parser for:
   - Selecting a tome (`start 3`).
   - Inspecting metadata (`describe node`, `inventory`, etc.).
   - Triggering shared actions (e.g., `stats`, `switch <tome>`).
3. Reuse existing HUD logic but allow dynamic node descriptions from JSON.
4. Implement `run_tome(tome_id)` loops:
   - Present current node.
   - Accept recognized commands.
   - Apply randomized effects/outcomes.
   - Update shared state (relics, tokens, flags).
   - Save state after each command (existing auto-save mechanism).

### Phase 3 – Persistence & replay
1. Auto-save player profile after each command (already in `pro_fishing_game.py`; extend to include `currentTome`, `nodeHistory`).
2. Provide `resume` command that reloads last node from save.
3. Add `newgame <profile>` to start fresh while preserving relic/faction networks.

### Phase 4 – Documentation & training
1. Rework README + new docs:
   - `RUN_DETAILS.md` already documents running CLI; expand with anthology instructions.
   - Add `ANTHOLOGY_PROJECT_PLAN.md` (this file) as roadmap.
   - Add `TOME_REFERENCE.md` summarizing per-tome metadata (pull from JSON).
2. Keep doc table linking each tale to its source file for reference/troubleshooting.

### Phase 5 – Future-proofing (optionally)
1. Provide simple tooling for future AI contributions:
   - `tools/add_tome.py` prompts for sections (title, nodes, hooks).
   - Automatically integrates new JSON into menu/stat map.
2. Add tests verifying:
   - Menu loads without duplication.
   - Persistent flags behave (no `KeyError` when referencing new ones).
   - Node randomness stays within bounds (e.g., `d6` generics).

## 5. Milestones (suggested)

| Step | Deliverable | Owner (you or AI) |
| --- | --- | --- |
| 1 | Parse text tomes → JSON data | you + script |
| 2 | Expand engine to load active tome & present nodes | me/AI (since code change required) |
| 3 | Extend persistence + prompts for anthology state | me/AI |
| 4 | Document new workflow + update README | done/once curated |
| 5 | Add new entries (future AI stories) via helper script | future work |

## 6. Notes / Next Actions

- For now, manually review each text file to ensure no unique lore (The Fracture, Chronosphere) gets lost—capture everything in the JSON.
- Keep `pyline_saves.json` local; `.gitignore` already excludes it.
- When ready to start a new arc, spawn a new `playerProfile` and let the prompt show the selected tome name.
- If you’d like me to take ownership of the ingestion step (parsing & structuring), just drop the raw files and I’ll generate the JSON + sample CLI run for one tome to prove the pattern.

--- 

Ready when you are. Once you confirm the priorities (data ingestion vs. engine expansion), I can help execute the exact steps, generate sample JSON, and provide CLI run flows for any specific tome you want to pilot first.
