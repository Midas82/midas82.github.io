# Game Details

## Core Loop
- Every session starts with a player name prompt; the HUD auto-loads that profile from `pyline_saves.json` if it exists.
- HUD lines display player, location, gear, tokens, inventory value, total casts/fish/tokens, and record catch.
- Commands are text-only: `cast` (with a 3–7 second bite wait), `bag`, `market`, `help`, and `quit`.

## Gear & Biomes (future)
- **Rod level** is intended for long-term progression; higher levels could tilt rarity odds and unlock bigger catches.
- **Bait choices** tune risk/reward: `WORM` is balanced, `LURE` favors Uncommon/Rare but ups the chance of no bite, and `SHRIMP` targets high-end fish at a token cost.
- **Boats** gate access to deeper waters: `SHORE` → `DINGHY` → `OFFSHORE`, each unlocking new location codes.
- **Locations** such as `[L-1] Stillwater Lake`, `[R-1] Rocky River`, and `[S-1] Open Sea` will adjust rarity curves and fish pools.

## Persistence
- Saves capture tokens, inventory, last catch, gear, and stats after every command (including market sales).
- Save data lives in `pyline_saves.json` and is ignored by Git thanks to `.gitignore`.
- The file tracks per-angler `tokens`, `inventory`, `last_catch`, `gear`, and `stats`.

## Stats
- `total_casts`, `total_fish_caught`, `lifetime_tokens_earned`
- `biggest_catch_value` with descriptive string to highlight career highlights

## Prompt
- Colored prompt shows `player@location$` (ANSI colors by default; set `NO_COLOR=1` to run in mono terminals).
