# Running & Sharing

## Running locally
1. Optionally create a virtualenv (recommended on Arch/Termux): `python -m venv venv && source venv/bin/activate`.
2. Install dependencies: `pip install -r requirements.txt`.
3. Launch the CLI: `python pro_fishing_game.py`.
4. Enter your angler name to resume or create a profile, then use `cast`, `bag`, `market`, `help`, and `quit`.
5. The prompt reads like `midas@L-1$`, and saves update `pyline_saves.json` after every loop iteration.

## Docker memory (optional)
- The Dockerfile still builds the CLI app even though it no longer needs graphics—`docker build -t py-line-fishing .` and `docker run --rm -it py-line-fishing` will start the CLI inside the container.

## Sharing
- Saves are ignored by Git; copy `pyline_saves.json` if you want to hand your career to a friend.
- To push to GitHub: `git remote add origin git@github.com:<username>/py-line-fishing.git` and `git push -u origin main`.
- The repo is intended to remain private—invite collaborators or share export archives/images manually.

## Testing
- `python -m py_compile pro_fishing_game.py` verifies syntax.
