import random
import sys
import time
import json
from pathlib import Path

# --- Save system ---

SAVE_FILE = Path("pyline_saves.json")

# Global game state (will be overridden if we load a save)
player_name = "UNKNOWN"

inventory = []   # list of catches (dicts)
tokens = 0
last_catch = None

gear = {
    "rod_level": 1,
    "bait": "WORM",
    "boat": "SHORE",
    "location_code": "L-1",
    "location_name": "Stillwater Lake",
}

stats = {
    "total_casts": 0,
    "total_fish_caught": 0,
    "lifetime_tokens_earned": 0,
    "biggest_catch_value": 0,
    "biggest_catch_desc": "",
}

RESET = "\033[0m"
BOLD = "\033[1m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
GREEN = "\033[92m"
MAGENTA = "\033[95m"


def color(text: str, code: str) -> str:
    return f"{code}{text}{RESET}"


def load_all_saves():
    if not SAVE_FILE.exists():
        return {}
    try:
        with SAVE_FILE.open("r") as f:
            return json.load(f)
    except Exception:
        return {}


def save_all_saves(data: dict):
    with SAVE_FILE.open("w") as f:
        json.dump(data, f, indent=2)


def get_player_state():
    return {
        "tokens": tokens,
        "inventory": inventory,
        "last_catch": last_catch,
        "gear": gear,
        "stats": stats,
    }


def load_player_state(state: dict):
    global tokens, inventory, last_catch, gear, stats

    tokens = state.get("tokens", 0)
    inventory[:] = state.get("inventory", [])
    last_catch_state = state.get("last_catch")
    last_catch_obj = last_catch_state if isinstance(last_catch_state, dict) else None
    last_catch = last_catch_obj

    gear.update(state.get("gear", {}))
    stats.update(state.get("stats", {}))


def load_player(name: str):
    all_saves = load_all_saves()
    state = all_saves.get(name)
    if state:
        load_player_state(state)
        return True
    return False


def save_player(name: str):
    all_saves = load_all_saves()
    all_saves[name] = get_player_state()
    save_all_saves(all_saves)

# --- RNG / Fish Data ---

rarity_probabilities = {
    "Common": 0.6,
    "Uncommon": 0.25,
    "Rare": 0.1,
    "Legendary": 0.05,
}

FISH_LIST = [
    {
        "id": "sea_bass",
        "name": "Sea Bass",
        "rarity": "Common",
        "min_weight": 1.0,
        "max_weight": 5.0,
        "base_price": 5,
    },
    {
        "id": "carp",
        "name": "Carp",
        "rarity": "Common",
        "min_weight": 0.5,
        "max_weight": 3.0,
        "base_price": 4,
    },
    {
        "id": "perch",
        "name": "Perch",
        "rarity": "Common",
        "min_weight": 0.3,
        "max_weight": 2.5,
        "base_price": 3,
    },
    {
        "id": "tuna",
        "name": "Tuna",
        "rarity": "Uncommon",
        "min_weight": 5.0,
        "max_weight": 25.0,
        "base_price": 20,
    },
    {
        "id": "salmon",
        "name": "Salmon",
        "rarity": "Uncommon",
        "min_weight": 2.0,
        "max_weight": 8.0,
        "base_price": 15,
    },
    {
        "id": "catfish",
        "name": "Catfish",
        "rarity": "Uncommon",
        "min_weight": 1.5,
        "max_weight": 10.0,
        "base_price": 12,
    },
    {
        "id": "pufferfish",
        "name": "Pufferfish",
        "rarity": "Rare",
        "min_weight": 1.0,
        "max_weight": 6.0,
        "base_price": 35,
    },
    {
        "id": "marlin",
        "name": "Marlin",
        "rarity": "Rare",
        "min_weight": 15.0,
        "max_weight": 60.0,
        "base_price": 60,
    },
    {
        "id": "coelacanth",
        "name": "Coelacanth",
        "rarity": "Legendary",
        "min_weight": 30.0,
        "max_weight": 80.0,
        "base_price": 120,
    },
    {
        "id": "golden_carp",
        "name": "Golden Carp",
        "rarity": "Legendary",
        "min_weight": 2.0,
        "max_weight": 4.0,
        "base_price": 150,
    },
]

# --- Core Logic ---

def roll_rarity():
    rarities = list(rarity_probabilities.keys())
    probabilities = list(rarity_probabilities.values())
    return random.choices(rarities, probabilities)[0]


def cast_line():
    global last_catch, stats

    stats["total_casts"] += 1

    rarity = roll_rarity()
    candidates = [f for f in FISH_LIST if f["rarity"] == rarity]
    if not candidates:
        last_catch = None
        return None

    fish = random.choice(candidates)
    weight = round(random.uniform(fish["min_weight"], fish["max_weight"]), 1)
    min_w = max(fish["min_weight"], 0.1)
    value = int(fish["base_price"] * (weight / min_w))

    catch = {
        "fish_name": fish["name"],
        "rarity": fish["rarity"],
        "weight": weight,
        "value": value,
    }

    inventory.append(catch)
    stats["total_fish_caught"] += 1

    if catch["value"] > stats["biggest_catch_value"]:
        stats["biggest_catch_value"] = catch["value"]
        stats["biggest_catch_desc"] = (
            f"{catch['fish_name']} ({catch['rarity']}) {catch['weight']}kg"
        )

    last_catch = catch
    return catch


def get_inventory_value():
    return sum(item["value"] for item in inventory)


def sell_all():
    global tokens, inventory, stats

    if not inventory:
        return 0

    total = get_inventory_value()
    tokens += total
    stats["lifetime_tokens_earned"] += total
    inventory = []
    return total

# --- UI Helpers (Text-Only) ---

def print_hud():
    sep = color("=" * 60, MAGENTA)
    print(sep)
    print(f" {color('py-line fishing :: CLI Edition', BOLD)}")
    print(
        f" Player : {color(player_name, GREEN)}"
        f" | Location: {color('[' + gear['location_code'] + ']', CYAN)} "
        f"{gear['location_name']}"
    )
    print(
        f" Rod: {color('Lv' + str(gear['rod_level']), YELLOW)}  "
        f"Bait: {color(gear['bait'], GREEN)}  "
        f"Boat: {color(gear['boat'], CYAN)}"
    )
    print(
        f" Tokens: {color(str(tokens), YELLOW)}  "
        f"Bag: {color(str(len(inventory)), GREEN)} fish "
        f"(value: {color(str(get_inventory_value()), YELLOW)}T)"
    )
    print(color("-" * 60, MAGENTA))
    print(
        color(
            f" Casts: {stats['total_casts']}  "
            f"Caught: {stats['total_fish_caught']}  "
            f"Lifetime: {stats['lifetime_tokens_earned']}T",
            CYAN,
        )
    )
    if stats["biggest_catch_value"] > 0:
        print(
            color(
                f" Record: {stats['biggest_catch_desc']} "
                f"[{stats['biggest_catch_value']}T]",
                YELLOW,
            )
        )
    else:
        print(color(" Record: none yet", MAGENTA))
    print(sep)
    if last_catch:
        lc = last_catch
        print(
            f" Last catch: {color(lc['fish_name'], BOLD)} "
            f"({color(lc['rarity'], CYAN)}) "
            f"{lc['weight']}kg [{color(str(lc['value']), YELLOW)}T]"
        )
    else:
        print(color(" Last catch: none", MAGENTA))
    print(color("-" * 60, MAGENTA))
    commands_line = " | ".join(
        [
            color("cast", GREEN),
            color("bag", CYAN),
            color("market", YELLOW),
            color("help", MAGENTA),
            color("quit", MAGENTA),
        ]
    )
    print(f" Commands: {commands_line}")
    print(color("-" * 60, MAGENTA))


def print_bag():
    if not inventory:
        print(" Your bag is empty.")
        return
    print(" Your bag:")
    for i, item in enumerate(inventory, 1):
        print(
            f"  {i:2d}. {item['fish_name']} ({item['rarity']}) "
            f"{item['weight']}kg [{item['value']}T]"
        )
    print(f" Total value: {get_inventory_value()}T")


def print_help():
    print(" Commands:")
    print("  cast   - cast your line")
    print("  bag    - show fish in your bag")
    print("  market - sell all fish for tokens")
    print("  help   - show this help")
    print("  quit   - exit game")


def market():
    print("\n=== FISH MARKET ===")
    print(f" Fish in bag : {len(inventory)}")
    total = get_inventory_value()
    print(f" Total value : {total} tokens")
    if not inventory:
        print(" You have nothing to sell.")
        return

    choice = input(" Sell all fish? [y/N]: ").strip().lower()
    if choice == "y":
        gained = sell_all()
        print(f" Sold everything for {gained} tokens.")
    else:
        print(" Kept your fish.")

# --- Main Loop ---

def main():
    global player_name

    print("\nWelcome to py-line fishing (CLI). Type 'help' if lost.\n")
    name = input(" Enter angler name: ").strip()
    if not name:
        name = "Guest"
    player_name = name

    if load_player(player_name):
        print(f" Loaded save for {player_name}.\n")
    else:
        print(f" New angler created: {player_name}.\n")

    try:
        while True:
            print_hud()
            prompt = (
                f" {color(player_name, GREEN)}"
                f"@{color(gear['location_code'], CYAN)}$ "
            )
            cmd = input(prompt).strip().lower()

            if cmd == "cast":
                print(" You cast your line...")
                wait = random.randint(3, 7)
                print(f" Waiting for a bite (~{wait}s)...")
                time.sleep(wait)
                catch = cast_line()
                if catch:
                    print(
                        f" -> You caught a {catch['fish_name']} ({catch['rarity']}) "
                        f"{catch['weight']}kg worth {catch['value']}T!"
                    )
                else:
                    print(" Nothing bites this time.")
                print()

            elif cmd == "bag":
                print_bag()
                print()

            elif cmd == "market":
                market()
                print()

            elif cmd in ("help", "?"):
                print_help()
                print()

            elif cmd in ("quit", "exit"):
                print(" Saving and exiting. Goodbye.")
                save_player(player_name)
                break

            else:
                print(" Unknown command. Type 'help' for options.\n")

            save_player(player_name)

    except (KeyboardInterrupt, EOFError):
        print("\n\nInterrupted. Saving and exiting. Goodbye.")
        save_player(player_name)
        sys.exit(0)


if __name__ == "__main__":
    main()
